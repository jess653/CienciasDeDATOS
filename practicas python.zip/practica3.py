import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from scipy.stats import ttest_ind


# Dataset sintético
np.random.seed(123)
n = 600
logistica = pd.DataFrame({
    "distancia_km": np.random.normal(300, 50, n),
    "tiempo_entrega_hrs": np.random.normal(20, 5, n),
    "tipo_transporte": np.random.choice(["Terrestre", "Aéreo"], n),
    "costo": np.random.normal(500, 100, n)
})

# Imputación de NA con mediana
logistica.loc[np.random.choice(n, 20), "distancia_km"] = np.nan
logistica["distancia_km"].fillna(logistica["distancia_km"].median(), inplace=True)

# Descriptivos
print(logistica["tiempo_entrega_hrs"].mean(), logistica["tiempo_entrega_hrs"].std())

# Correlación
print(logistica[["distancia_km", "tiempo_entrega_hrs"]].corr())

# Agrupación
print(logistica.groupby("tipo_transporte")[["tiempo_entrega_hrs", "costo"]].mean())

# Prueba t-test
from scipy.stats import ttest_ind
terrestre = logistica[logistica["tipo_transporte"]=="Terrestre"]["tiempo_entrega_hrs"]
aereo = logistica[logistica["tipo_transporte"]=="Aéreo"]["tiempo_entrega_hrs"]
print(ttest_ind(terrestre, aereo))

# Visualizaciones
sns.scatterplot(x="distancia_km", y="tiempo_entrega_hrs", hue="tipo_transporte", data=logistica)
plt.show()

sns.boxplot(x="tipo_transporte", y="tiempo_entrega_hrs", data=logistica)
plt.show()
