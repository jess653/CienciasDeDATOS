import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans

# Dataset sintético
np.random.seed(444)
n = 400
df_red = pd.DataFrame({
    "latencia": np.random.normal(20, 5, n),
    "intentos_fallidos": np.random.poisson(1, n),
    "tamano_paquete": np.random.normal(500, 100, n)
})

# Etiqueta de ataque
df_red["es_ataque"] = ((df_red["intentos_fallidos"] > 2) | (df_red["latencia"] > 35)).astype(int)

# --- Regresión Logística ---
X = df_red[["latencia","intentos_fallidos","tamano_paquete"]]
y = df_red["es_ataque"]
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)

modelo_log = LogisticRegression().fit(X_train,y_train)
y_pred = modelo_log.predict(X_test)
print("Accuracy Logística:", accuracy_score(y_test,y_pred))

# --- Clasificación KNN ---
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train,y_train)
print("Accuracy KNN:", knn.score(X_test,y_test))

# --- Clustering K-Means ---
kmeans = KMeans(n_clusters=2, random_state=111).fit(X)
df_red["cluster"] = kmeans.labels_
print(pd.crosstab(df_red["es_ataque"], df_red["cluster"]))
