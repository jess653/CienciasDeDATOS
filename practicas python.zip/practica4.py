import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Dataset sintético
np.random.seed(42)
n = 200
datos = pd.DataFrame({
    "temp_nucleo": np.random.normal(100, 5, n),
    "presion_interna": np.random.normal(50, 10, n),
    "vibracion_motor": np.random.normal(20, 2, n),
    "flujo_gas": np.random.normal(20, 2, n),
    "oxigeno": np.random.normal(15, 1, n),
    "co2": np.random.normal(25, 3, n),
    "humedad": np.random.uniform(30, 40, n),
    "voltaje": np.random.normal(220, 2, n),
    "corriente": np.random.normal(15, 0.5, n),
    "ruido_db": np.random.normal(60, 5, n),
    "eficiencia": np.random.normal(80, 5, n)
})

# Escalamiento
scaler = StandardScaler()
scaled = scaler.fit_transform(datos)

# PCA
pca = PCA()
pca.fit(scaled)

print("Varianza acumulada:", np.cumsum(pca.explained_variance_ratio_))

plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel("Componentes")
plt.ylabel("Varianza acumulada")
plt.show()
