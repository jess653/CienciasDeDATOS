import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

np.random.seed(123)
n = 300
datos_red = pd.DataFrame({
    "duracion_ms": np.random.normal(50, 10, n),
    "paquetes_enviados": np.random.normal(100, 20, n),
    "errores_checksum": np.random.poisson(2, n),
    "latencia_avg": np.random.normal(15, 5, n),
    "jitter": np.random.normal(2, 0.5, n),
    "uso_memoria_sw": np.random.normal(40, 10, n),
    "peticiones_http": np.random.normal(200, 50, n)
})

# Variables dependientes
datos_red["bytes_enviados"] = datos_red["paquetes_enviados"]*1500 + np.random.normal(0,500,n)
datos_red["reintentos_tcp"] = datos_red["errores_checksum"]*1.5 + np.random.normal(0,0.5,n)
datos_red["carga_cpu_router"] = datos_red["paquetes_enviados"]*0.4 + datos_red["latencia_avg"]*0.2

# PCA
scaled = StandardScaler().fit_transform(datos_red)
pca = PCA()
pca.fit(scaled)

print("Varianza acumulada:", np.cumsum(pca.explained_variance_ratio_))

plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel("Componentes")
plt.ylabel("Varianza acumulada")
plt.title("Scree Plot: Tráfico de Red")
plt.show()
