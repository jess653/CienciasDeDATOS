import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans

# Dataset sintético
np.random.seed(789)
n = 500
df_empleados = pd.DataFrame({
    "experiencia": np.random.normal(5, 2, n),
    "certificaciones": np.random.poisson(3, n),
    "habilidades_sociales": np.random.uniform(1, 10, n),
    "remoto": np.random.choice([0,1], n)
})
df_empleados["salario"] = 25000 + df_empleados["experiencia"]*5000 + df_empleados["certificaciones"]*2000 + np.random.normal(0,3000,n)
df_empleados["retencion"] = (df_empleados["salario"]>30000).astype(int)

# --- Regresión Lineal ---
X = df_empleados[["experiencia","certificaciones"]]
y = df_empleados["salario"]
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)
modelo = LinearRegression().fit(X_train,y_train)
print("Coeficientes:", modelo.coef_)
print("Intercepto:", modelo.intercept_)

# --- Clasificación KNN ---
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, (y_train>30000).astype(int))
print("Accuracy KNN:", knn.score(X_test,(y_test>30000).astype(int)))

# --- Clustering K-Means ---
datos_clustering = df_empleados[["experiencia","salario"]].values
kmeans = KMeans(n_clusters=3, random_state=42).fit(datos_clustering)
df_empleados["cluster"] = kmeans.labels_

sns.scatterplot(x="experiencia", y="salario", hue="cluster", data=df_empleados, palette="Set1")
plt.title("Segmentación de Empleados por Perfil")
plt.show()
