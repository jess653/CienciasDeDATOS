import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

np.random.seed(456)
n = 400
datos_urbanos = pd.DataFrame({
    "temp_ambiente": np.random.normal(28, 4, n),
    "humedad_rel": np.random.normal(60, 10, n),
    "densidad_vehiculos": np.random.normal(120, 30, n),
    "velocidad_viento": np.random.normal(15, 5, n),
    "radiacion_solar": np.random.normal(800, 100, n),
    "conteo_peatones": np.random.normal(50, 15, n)
})

# Variables dependientes
datos_urbanos["co2_ppm"] = datos_urbanos["densidad_vehiculos"]*3.5 + np.random.normal(300,50,n)
datos_urbanos["no2_ppb"] = datos_urbanos["co2_ppm"]*0.1 + np.random.normal(5,2,n)
datos_urbanos["particulas_pm25"] = datos_urbanos["co2_ppm"]*0.05 + np.random.normal(10,3,n)
datos_urbanos["nivel_ruido_db"] = datos_urbanos["densidad_vehiculos"]*0.2 + 50 + np.random.normal(0,5,n)

scaled = StandardScaler().fit_transform(datos_urbanos)
pca = PCA()
pca.fit(scaled)

print("Varianza acumulada:", np.cumsum(pca.explained_variance_ratio_))

plt.plot(np.cumsum(pca.explained_variance_ratio_))
plt.xlabel("Componentes")
plt.ylabel("Varianza acumulada")
plt.title("Scree Plot: Sensores Smart City")
plt.show()
