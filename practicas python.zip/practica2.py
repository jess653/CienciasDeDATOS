import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Dataset sintético
np.random.seed(42)
n = 500
data = pd.DataFrame({
    "temperatura": np.random.normal(75, 5, n),
    "presion": np.random.normal(30, 3, n),
    "tasa_error": np.random.normal(0.05, 0.01, n),
    "turno": np.random.choice(["Matutino", "Vespertino"], n)
})

# Estadísticos
print("Media:", data["temperatura"].mean())
print("Mediana:", data["temperatura"].median())
print("Desviación estándar:", data["temperatura"].std())

# Correlación
print(data[["temperatura", "tasa_error"]].corr())

# Comparación por turnos
print(data.groupby("turno")["tasa_error"].mean())

# Boxplot
sns.boxplot(x="turno", y="tasa_error", data=data)
plt.show()

# Scatter con regresión
sns.lmplot(x="temperatura", y="tasa_error", data=data)
plt.show()